# Fullbay API Ingestion Lambda Function
__version__ = "1.0.0"