"""
Fullbay API client for data retrieval.

Handles authentication, rate limiting, and data fetching from the Fullbay API.
Structured to allow easy addition of different endpoints and data types.
"""

import logging
import time
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .config import Config

logger = logging.getLogger(__name__)


class FullbayClient:
    """
    Client for interacting with the Fullbay API.
    """
    
    def __init__(self, config: Config):
        """
        Initialize the Fullbay API client.
        
        Args:
            config: Configuration object containing API credentials and endpoints
        """
        self.config = config
        self.base_url = f"{config.fullbay_api_base_url}/{config.fullbay_api_version}"
        self.session = self._create_session()
        
    def _create_session(self) -> requests.Session:
        """
        Create HTTP session with retry strategy and timeout configuration.
        
        Returns:
            Configured requests Session
        """
        session = requests.Session()
        
        # Configure retry strategy
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST"]
        )
        
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        # Set default headers
        session.headers.update(self.config.get_fullbay_headers())
        
        return session
    
    def fetch_data(self, endpoint: str = "work-orders", **kwargs) -> List[Dict[str, Any]]:
        """
        Fetch data from the Fullbay API.
        
        Args:
            endpoint: API endpoint to fetch from (default: work-orders)
            **kwargs: Additional query parameters
            
        Returns:
            List of records retrieved from the API
            
        Raises:
            Exception: If API request fails or returns invalid data
        """
        try:
            logger.info(f"Fetching data from endpoint: {endpoint}")
            
            # Build URL and parameters
            url = f"{self.base_url}/{endpoint}"
            params = self._build_query_params(**kwargs)
            
            logger.debug(f"Request URL: {url}")
            logger.debug(f"Request params: {params}")
            
            # Make API request
            response = self.session.get(url, params=params, timeout=30)
            
            # Log response details
            logger.info(f"API response status: {response.status_code}")
            logger.debug(f"Response headers: {dict(response.headers)}")
            
            # Handle rate limiting
            if response.status_code == 429:
                retry_after = int(response.headers.get("Retry-After", 60))
                logger.warning(f"Rate limited. Waiting {retry_after} seconds...")
                time.sleep(retry_after)
                return self.fetch_data(endpoint, **kwargs)
            
            # Raise for HTTP errors
            response.raise_for_status()
            
            # Parse response
            data = response.json()
            
            # Handle different response formats
            if isinstance(data, dict):
                # If response is paginated, extract the data array
                records = data.get("data", data.get("results", [data]))
                total_count = data.get("total", len(records))
                logger.info(f"Retrieved {len(records)} records (total available: {total_count})")
                
                # Handle pagination if needed (for future enhancement)
                if self._should_fetch_more_pages(data):
                    logger.info("Multiple pages detected - fetching additional pages...")
                    additional_records = self._fetch_paginated_data(endpoint, data, **kwargs)
                    records.extend(additional_records)
                
            elif isinstance(data, list):
                records = data
                logger.info(f"Retrieved {len(records)} records")
            else:
                raise Exception(f"Unexpected response format: {type(data)}")
            
            # Validate and enrich records
            validated_records = self._validate_and_enrich_records(records)
            
            logger.info(f"Successfully processed {len(validated_records)} valid records")
            return validated_records
            
        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed: {e}")
            raise Exception(f"Failed to fetch data from Fullbay API: {e}")
        except Exception as e:
            logger.error(f"Unexpected error during API fetch: {e}")
            raise
    
    def _build_query_params(self, **kwargs) -> Dict[str, Any]:
        """
        Build query parameters for API requests.
        
        Args:
            **kwargs: Additional parameters
            
        Returns:
            Dict of query parameters
        """
        params = {
            "limit": kwargs.get("limit", 100),  # Default page size
            "offset": kwargs.get("offset", 0),
        }
        
        # Add date filters if not specified (default to last 24 hours)
        if "start_date" not in kwargs and "updated_since" not in kwargs:
            # Fetch records updated in the last 24 hours
            yesterday = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
            params["updated_since"] = yesterday.isoformat()
        
        # Add any additional parameters
        params.update({k: v for k, v in kwargs.items() if v is not None})
        
        return params
    
    def _should_fetch_more_pages(self, response_data: Dict[str, Any]) -> bool:
        """
        Determine if there are more pages to fetch.
        
        Args:
            response_data: API response data
            
        Returns:
            True if more pages should be fetched
        """
        # This is a placeholder - adjust based on actual Fullbay API pagination format
        has_next = response_data.get("has_next", False)
        next_url = response_data.get("next")
        
        return has_next or next_url is not None
    
    def _fetch_paginated_data(
        self, 
        endpoint: str, 
        initial_response: Dict[str, Any], 
        **kwargs
    ) -> List[Dict[str, Any]]:
        """
        Fetch additional pages of data.
        
        Args:
            endpoint: API endpoint
            initial_response: First page response
            **kwargs: Query parameters
            
        Returns:
            List of additional records
        """
        all_records = []
        current_offset = kwargs.get("offset", 0) + kwargs.get("limit", 100)
        
        # Placeholder pagination logic - adjust based on actual API
        while self._should_fetch_more_pages(initial_response):
            try:
                next_params = kwargs.copy()
                next_params["offset"] = current_offset
                
                url = f"{self.base_url}/{endpoint}"
                response = self.session.get(url, params=next_params, timeout=30)
                response.raise_for_status()
                
                data = response.json()
                records = data.get("data", data.get("results", []))
                
                if not records:
                    break
                    
                all_records.extend(records)
                current_offset += len(records)
                initial_response = data  # Update for next iteration
                
                # Rate limiting courtesy
                time.sleep(0.1)
                
            except Exception as e:
                logger.warning(f"Failed to fetch page at offset {current_offset}: {e}")
                break
        
        return all_records
    
    def _validate_and_enrich_records(self, records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Validate and enrich records with metadata.
        
        Args:
            records: Raw records from API
            
        Returns:
            List of validated and enriched records
        """
        validated_records = []
        current_time = datetime.now(timezone.utc).isoformat()
        
        for record in records:
            try:
                # Basic validation - ensure required fields exist
                if not isinstance(record, dict):
                    logger.warning(f"Skipping invalid record (not a dict): {record}")
                    continue
                
                # Add ingestion metadata
                enriched_record = record.copy()
                enriched_record["_ingestion_timestamp"] = current_time
                enriched_record["_ingestion_source"] = "fullbay_api"
                
                # Validate required fields (adjust based on actual Fullbay API response)
                required_fields = ["id"]  # Minimum required field
                missing_fields = [field for field in required_fields if field not in record]
                
                if missing_fields:
                    logger.warning(f"Skipping record missing required fields {missing_fields}: {record.get('id', 'unknown')}")
                    continue
                
                validated_records.append(enriched_record)
                
            except Exception as e:
                logger.warning(f"Error validating record: {e}")
                continue
        
        return validated_records
    
    def test_connection(self) -> bool:
        """
        Test API connection and authentication.
        
        Returns:
            True if connection is successful
        """
        try:
            # Use a lightweight endpoint for testing
            test_url = f"{self.base_url}/health"  # Adjust based on actual API
            response = self.session.get(test_url, timeout=10)
            
            if response.status_code == 200:
                logger.info("API connection test successful")
                return True
            else:
                logger.error(f"API connection test failed: {response.status_code}")
                return False
                
        except Exception as e:
            logger.error(f"API connection test error: {e}")
            return False